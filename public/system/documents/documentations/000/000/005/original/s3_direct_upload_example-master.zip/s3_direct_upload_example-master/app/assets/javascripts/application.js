//= require jquery
//= require jquery_ujs
//= require s3_direct_upload
//= require_tree .