require 'test_helper'

class DocumentsControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
